<div class="banner-size-modal">
    <div class="modal fade" id="cropImagePop" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                     <h2>Resize Banner</h2>
                </div>
                <div class="modal-body">
                    <div id="upload-demo" class="center-block"></div>
                </div>
                <div class="form-submit-bttns upload-action-btn mt-0">
                    <button type="button" class="btn btn-cancel" data-dismiss="modal" id="cancelCropBtn">Cancel</button>
                    <button type="button" id="cropImageBtn" class="btn btn-submit">Crop Photo</button>
                </div>
            </div>
        </div>
    </div>
</div>