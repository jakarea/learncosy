<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Certificate</title>
</head>
<body>
    <!-- Your PDF content goes here -->
    <img src="{{ public_path($certificatePath) }}" width="100%" height="auto">
</body>
</html>
