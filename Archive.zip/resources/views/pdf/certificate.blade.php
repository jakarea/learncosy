<!DOCTYPE html>
<html>
<head>
    <title>Certificate</title>
    <style>
        @page {
            size: 400mm 300mm;
            margin: 10mm;
        }
        body {
            margin: 0;
            padding: 0;
        }
        img {
            width: 100%;
        }
    </style>
</head>
<body>
    <img src="{{ $certificateImage }}" alt="Certificate" >
</body>
</html>
