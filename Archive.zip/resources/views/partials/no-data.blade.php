<div class="no-data-found">
    <i class="fa-solid fa-circle-exclamation"></i>
    <p>No data found!</p>
</div>