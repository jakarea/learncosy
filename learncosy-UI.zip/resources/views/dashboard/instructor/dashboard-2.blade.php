@extends('layouts/instructor')
@section('title', 'Dashboard') 

@section('content')
<h2>
    Welcome to Instructor Dashboard
</h2>
@endsection
