In the example above, we use the PDF class to generate the PDF file by loading a view (pdf.package) and passing data to it. Then, we retrieve the binary content of the PDF using $pdf->output().

I am from PDF ATTACHEDMENT