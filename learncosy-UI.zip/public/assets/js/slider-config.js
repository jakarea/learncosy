/* all slider start */
$('.add-slider').slick({
  infinite: false,
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: true,
  dots: false,
  adaptiveHeight: true,
  prevArrow: '.prev',
  nextArrow: '.next'
});