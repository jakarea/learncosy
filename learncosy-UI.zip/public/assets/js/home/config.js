/* all slider start */
$('.feedback-slider').slick({
  infinite: true,
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  autoPlay: true,
  centerMode: false,
  dots: true,
});
