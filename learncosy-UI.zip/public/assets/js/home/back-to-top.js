var backToTopButton = document.getElementById("back-to-top");

window.addEventListener("scroll", function () {
  if (window.pageYOffset > 100) {
    // Show back-to-top button
    backToTopButton.style.display = "block";
  } else {
    // Hide back-to-top button
    backToTopButton.style.display = "none";
  }
});

backToTopButton.addEventListener("click", function () {
  // Smooth scroll to top of page
  window.scrollTo({ top: 0, behavior: "smooth" });
});