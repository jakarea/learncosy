<?php

return [
    'size' => 10240000, // 100MB 
];