<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\VimeoData;
class VimeoController extends Controller
{
    //
}
